/////////////////////////////////////////////////////////////////////////////////
//
// This confidential and proprietary software may be used only as authorized
// by a licensing agreement from Synopsys Inc. In the event of publication,
// the following notice is applicable:
//
// (C) COPYRIGHT 2008 SYNOPSYS INC.  ALL RIGHTS RESERVED
//
// The entire notice above must be reproduced on all authorized copies.
//-----------------------------------------------------------------------------
// Filename    : get_systime.c
//
// Author      : Doron Meiraz, Synopsys Inc. Jul/12/10
//
// Description : get system time function
//
//
/////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <time.h>

// int main () { printf ("%d hours since January 1, 1970\n", get_systime()); return 0; }

int get_systime() {
    time_t seconds;
    seconds = time (NULL);
    return seconds;
}

